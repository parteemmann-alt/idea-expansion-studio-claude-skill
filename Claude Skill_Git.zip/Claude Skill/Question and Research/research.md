SKILL ACTION: Expand on Topic with Multi-Source Intelligence

├─ 2.1 Deep Research Questions
│  ├─ "Should I research recent case studies on this topic?"
│  ├─ "Do you want industry benchmarks included?"
│  ├─ "Should I analyze competitor approaches?"
│  ├─ "Do you want data-driven statistics?"
│  ├─ "Should I include emerging trends?"
│  └─ "What's the scope: Local/National/Global?"
│
├─ 2.2 Source Categorization Questions
│  ├─ "Which sources matter most?"
│  │  ├─ Academic research?
│  │  ├─ Industry reports?
│  │  ├─ Case studies?
│  │  ├─ Expert interviews (hypothetical)?
│  │  └─ Real-world data?
│  │
│  └─ "Should I cite sources or integrate seamlessly?"
│
└─ 2.3 Generate Expanded Concept Map
   └─ Multi-dimensional breakdown of the idea
      ├─ Historical context
      ├─ Current landscape
      ├─ Future opportunities
      └─ Potential challenges & solutions