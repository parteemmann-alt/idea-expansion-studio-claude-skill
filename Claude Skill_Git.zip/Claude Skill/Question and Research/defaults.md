
---

## Optional support file: `question-panel.md`

Keep this next to the skill if you want an even more editable questionnaire.

```markdown
# Editable Control Panel

Copy, edit, delete, or answer in shorthand.

## Q0 Idea lock
- Restatement correct? 
- Locked pieces:
- Exploratory pieces:
- Constraints:
- Extra sources:

## Q1 Depth
- Mode: conservative / exploratory
- Deepest branches:
- Ignore:
- Must use these phrases/positioning:

## Q2 Outputs
- [ ] A Deep-dive doc
- [ ] B Deck
- [ ] C One-pager
- [ ] D Illustrations
- [ ] E Design system
- [ ] F Animation
- [ ] G 3D / interactive
- [ ] H Landing page
- [ ] I Social/ad set
- [ ] J Roadmap/SOP
- [ ] K Other:

## Q3 Document
- Pages: 10 / 20 / 30 / 40 / 50 / 100 / 200 / 1000 / __
- Shape: playbook / memo / report / course / bible
- Density: executive / standard / academic-deep
- Batch: sample / chapter-by-chapter / full

## Q4 Deck
- Slides: 10 / 20 / 30 / 40 / 50 / 100 / __
- Job: pitch / workshop / sales / teaching / internal
- Style: dark premium / consulting / startup / editorial
- Format: HTML artifact / markdown / outline+notes

## Q5 Audience
- Who:
- After this they should:
- Market/geo:
- Public or internal:

## Q6 Voice
- Tone:
- Do not claim:
- Competitors:
- Language:

## Q7 Extras
- Illustrations:
- Design system:
- Animation:
- 3D subject:
- Style refs:

## Q8 Order
- First output:
- Sample first? yes/no
- Then: