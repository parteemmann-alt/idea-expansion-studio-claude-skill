# Length Map

Use this when the user picks a large number.

## 10 pages
Thesis, customer, offer, GTM wedge, 30-day plan.

## 20–30 pages
Full operator playbook. Enough to act.

## 40–60 pages
Playbook + examples, scripts, objection handling, channel detail.

## 100 pages
Department-level operating manual. Multiple personas, workflows, templates.

## 200–400 pages
Multi-part bible: strategy, product, GTM, brand, ops, finance, hiring.

## 1000 pages
Only as a planned encyclopedia.
Create 10 volumes of ~100 pages.
Generate Volume I index first, then Chapter 1.
Never autoset 1000 pages as a default.