TRIGGER: User inputs business/marketing idea

SKILL ACTIONS:
├─ 1.1 Parse & Summarize the Core Idea
│  └─ Extract: Key concept, target market, unique angle
│
├─ 1.2 Ask Clarifying Questions
│  ├─ What's your primary objective? (awareness, sales, education, etc.)
│  ├─ Who's your target audience? (B2B, B2C, niche, etc.)
│  ├─ What's your current knowledge level on this topic?
│  ├─ Are there specific pain points to address?
│  └─ What's your timeline & budget context?
│
└─ 1.3 Store Context for All Subsequent Phases
   └─ Create internal "project brief" document