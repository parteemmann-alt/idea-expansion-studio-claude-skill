SKILL ACTION: Generate All Selected Assets

OUTPUT STRUCTURE:
├─ 7.1 Presentation Deck (if selected)
│  ├─ Detailed slide-by-slide outline
│  ├─ Speaker notes
│  ├─ Visual specifications
│  ├─ Data visualization specs
│  └─ Implementation instructions
│
├─ 7.2 Master Document (if selected)
│  ├─ Complete formatted document
│  ├─ All sections fully expanded
│  ├─ Internal cross-references
│  ├─ Citation & sources
│  └─ Appendices
│
├─ 7.3 Visual Assets (if selected)
│  ├─ Illustration briefs & descriptions
│  ├─ Infographic specifications
│  ├─ Design guidelines
│  ├─ Color palettes & style guides
│  └─ Asset inventory list
│
├─ 7.4 Animation/Video (if selected)
│  ├─ Storyboard descriptions
│  ├─ Animation timing guides
│  ├─ Video scripts & shot lists
│  ├─ Sound design specs
│  └─ Technical requirements
│
├─ 7.5 Interactive Elements (if selected)
│  ├─ Wireframes/mockups
│  ├─ Functional specifications
│  ├─ Data flow diagrams
│  ├─ Code snippets/tech stack
│  └─ Integration guides
│
└─ 7.6 Master Delivery Package
   ├─ Index of all deliverables
   ├─ File organization guide
   ├─ Implementation roadmap
   ├─ Customization checklist
   ├─ Tips for using each asset
   └─ Next steps & recommendations