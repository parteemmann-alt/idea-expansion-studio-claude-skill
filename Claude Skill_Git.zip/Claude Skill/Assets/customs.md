SKILL ACTION: Flexible Asset Mix Selection

├─ 6.1 Ask About Custom Combinations
│  ├─ "Which combination works best?"
│  │  ├─ Option A: Deck + Document + Illustrations
│  │  ├─ Option B: Document + 3D Animation only
│  │  ├─ Option C: Deck + Video Script + Animations
│  │  ├─ Option D: Everything (full suite)
│  │  └─ Option E: Custom selection
│  │
│  └─ "Build your custom package:"
│     ├─ Presentation deck? (Yes/No + # slides)
│     ├─ Detailed document? (Yes/No + # pages)
│     ├─ Illustrations? (Yes/No + quantity & type)
│     ├─ Animations? (Yes/No + 2D/3D)
│     ├─ Video scripts? (Yes/No + type)
│     ├─ Interactive tools? (Yes/No + which)
│     └─ 3D models? (Yes/No + what)
│
├─ 6.2 Integration & Distribution Questions
│  ├─ "How should these work together?"
│  │  ├─ Sequential (presentation → document → assets)
│  │  ├─ Parallel (independent but coordinated)
│  │  └─ Integrated (cross-references, unified branding)
│  │
│  ├─ "Distribution format needed?"
│  │  ├─ Compressed folder (all files)
│  │  ├─ Cloud links (organized)
│  │  ├─ Embedded in doc/deck?
│  │  └─ Separate deliverables
│  │
│  └─ "Should I create:"
│     ├─ Master index/guide?
│     ├─ Version control document?
│     ├─ Usage guidelines?
│     └─ Customization instructions?
│
└─ 6.3 Revision & Iteration Questions
   ├─ "How many revision rounds?"
   ├─ "Should I flag areas for customization?"
   ├─ "Do you want a customization checklist?"
   └─ "Should I provide usage tips?"