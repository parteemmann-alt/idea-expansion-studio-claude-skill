SKILL ACTION: Modular PowerPoint/Presentation Builder

FIRST: Ask Page Count & Format Questions
├─ 3.1 Deck Scope Selection (Interactive)
│  ├─ "How many slides do you need?"
│  │  ├─ Quick Overview: 10 slides
│  │  ├─ Standard Pitch: 20 slides
│  │  ├─ Detailed Proposal: 30 slides
│  │  ├─ Comprehensive Strategy: 40 slides
│  │  ├─ Deep Dive: 50-100 slides
│  │  └─ Enterprise-Level: 100-200+ slides
│  │
│  └─ "What's the primary use case?"
│     ├─ Executive briefing
│     ├─ Team workshop
│     ├─ Client pitch
│     ├─ Internal training
│     └─ Public presentation
│
├─ 3.2 Deck Structure Questions
│  ├─ "Should I include:"
│  │  ├─ Executive summary?
│  │  ├─ Problem/opportunity statement?
│  │  ├─ Market analysis?
│  │  ├─ Solution deep-dive?
│  │  ├─ Implementation roadmap?
│  │  ├─ Financial projections?
│  │  ├─ Risk analysis?
│  │  ├─ Success metrics/KPIs?
│  │  └─ Call-to-action?
│  │
│  └─ "Which sections deserve the most detail?"
│
├─ 3.3 Design & Visual Questions
│  ├─ "What's your brand style?"
│  │  ├─ Corporate/Professional
│  │  ├─ Modern/Startup
│  │  ├─ Creative/Bold
│  │  ├─ Minimalist/Clean
│  │  └─ Industry-specific theme
│  │
│  ├─ "Should I include:"
│  │  ├─ Data visualizations? (charts, graphs)
│  │  ├─ Infographics?
│  │  ├─ Icons & illustrations?
│  │  ├─ Photo suggestions?
│  │  └─ Diagram layouts?
│  │
│  └─ "Color scheme preference?"
│
└─ 3.4 Presentation Deck Output
   ├─ Structured slide outline (markdown/text format)
   ├─ Detailed speaker notes for each slide
   ├─ Visual direction for each slide
   ├─ Data visualization specifications
   └─ Export instructions (for PowerPoint/Google Slides tools)