SKILL ACTION: Multi-Tier Deep-Dive Document Builder

FIRST: Ask Document Scope Questions
├─ 4.1 Document Length Selection (Interactive)
│  ├─ "What depth do you need?"
│  │  ├─ Executive Summary: 5-10 pages
│  │  ├─ Standard Report: 20 pages
│  │  ├─ Detailed Strategy: 30 pages
│  │  ├─ Comprehensive Analysis: 40-50 pages
│  │  ├─ Master Document: 100+ pages
│  │  └─ Research Tome: 200-500+ pages
│  │
│  └─ "What's the reader profile?"
│     ├─ C-Suite/Executives (summary + key insights)
│     ├─ Department Managers (actionable details)
│     ├─ Team Members (implementation focus)
│     ├─ External Stakeholders (pitch format)
│     └─ Academic/Research (comprehensive analysis)
│
├─ 4.2 Document Structure Questions
│  ├─ "Core sections to include:"
│  │  ├─ Executive Summary
│  │  ├─ Table of Contents
│  │  ├─ Introduction & Context
│  │  ├─ Market Analysis
│  │  │  ├─ Market size & growth
│  │  │  ├─ Customer segments
│  │  │  ├─ Competitive landscape
│  │  │  └─ Industry trends
│  │  ├─ Solution Deep-Dive
│  │  │  ├─ Product/Service breakdown
│  │  │  ├─ Value proposition
│  │  │  ├─ Differentiation
│  │  │  └─ Use cases
│  │  ├─ Implementation Roadmap
│  │  │  ├─ Phase breakdown
│  │  │  ├─ Timeline
│  │  │  ├─ Resource requirements
│  │  │  └─ Dependencies
│  │  ├─ Financial Projections
│  │  │  ├─ Revenue model
│  │  │  ├─ Cost structure
│  │  │  ├─ Break-even analysis
│  │  │  └─ ROI forecasts
│  │  ├─ Risk Assessment & Mitigation
│  │  ├─ Success Metrics & KPIs
│  │  ├─ Appendices & Reference Materials
│  │  └─ Bibliography/Sources
│  │
│  ├─ "Expansion preferences:"
│  │  ├─ How detailed should each concept be?
│  │  ├─ Should I include real examples?
│  │  ├─ Depth of technical explanations?
│  │  └─ How many sub-sections per section?
│  │
│  └─ "Special sections needed?"
│     ├─ SWOT analysis?
│     ├─ Personas & customer journeys?
│     ├─ Technology stack breakdown?
│     ├─ Regulatory/compliance considerations?
│     └─ Change management strategy?
│
├─ 4.3 Content Depth Questions
│  ├─ "For each concept, should I:"
│  │  ├─ Define & contextualize
│  │  ├─ Provide statistical evidence
│  │  ├─ Include case studies
│  │  ├─ Add implementation examples
│  │  ├─ Explain common pitfalls
│  │  └─ Suggest best practices
│  │
│  └─ "Citation style?"
│     ├─ APA
│     ├─ Chicago
│     ├─ Harvard
│     └─ Embedded references
│
└─ 4.4 Document Output
   ├─ Fully formatted document (markdown/text)
   ├─ Section-by-section breakdown
   ├─ Detailed concept explanations
   ├─ Real-world examples & case studies
   ├─ Data-backed insights
   ├─ Actionable recommendations
   ├─ Visual layout suggestions
   └─ Ready for conversion to Word/PDF