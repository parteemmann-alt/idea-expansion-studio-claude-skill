SKILL ACTION: Multi-Media Content Creation (Conditional)

FIRST: Ask Asset Requirements
├─ 5.1 Visual Assets Questions
│  ├─ "Do you need illustrations?"
│  │  ├─ Concept diagrams
│  │  ├─ Process flows
│  │  ├─ Infographics
│  │  ├─ Character illustrations
│  │  └─ Logo/brand concepts
│  │
│  ├─ "Should I specify:"
│  │  ├─ Art style? (flat, realistic, minimalist, etc.)
│  │  ├─ Color palettes?
│  │  ├─ Illustration descriptions (for designers)?
│  │  └─ Mood & tone?
│  │
│  └─ "Output format?"
│     ├─ Detailed design briefs (for designers)
│     ├─ SVG/vector specifications
│     ├─ Style guides
│     └─ Moodboards
│
├─ 5.2 Animation & Interactive Elements Questions
│  ├─ "Do you want animations?"
│  │  ├─ 2D animations?
│  │  ├─ 3D animations?
│  │  ├─ Interactive prototypes?
│  │  ├─ Explainer videos?
│  │  └─ Data visualizations (animated)?
│  │
│  ├─ "Animation specifications:"
│  │  ├─ Duration preferences?
│  │  ├─ Complexity level?
│  │  ├─ Software preference? (After Effects, Blender, etc.)
│  │  └─ Target format? (MP4, WebM, GIF, etc.)
│  │
│  └─ "What should animate?"
│     ├─ Concept progression
│     ├─ Timeline/roadmap
│     ├─ Data flows
│     ├─ 3D product demos
│     └─ Customer journey visualization
│
├─ 5.3 Video Content Questions
│  ├─ "Do you need video scripts?"
│  │  ├─ Explainer video (2-5 min)
│  │  ├─ Pitch deck video (5-15 min)
│  │  ├─ Training video series (multi-part)
│  │  ├─ Interview/testimonial format
│  │  └─ Narrative documentary style
│  │
│  ├─ "Video specifications:"
│  │  ├─ Length & pacing?
│  │  ├─ Tone? (professional, conversational, energetic)
│  │  ├─ Talking points vs. full script?
│  │  └─ Storyboard needed?
│  │
│  └─ "Deliverables?"
│     ├─ Script only
│     ├─ Script + storyboard
│     ├─ Script + shot list
│     └─ Full production guide
│
├─ 5.4 Interactive Content Questions
│  ├─ "Do you want interactive tools?"
│  │  ├─ Interactive calculators? (ROI, pricing, etc.)
│  │  ├─ Decision trees/questionnaires?
│  │  ├─ Interactive infographics?
│  │  ├─ Prototype/wireframes?
│  │  └─ Web component specs?
│  │
│  └─ "Technology stack preferred?"
│     ├─ HTML/CSS/JS
│     ├─ React/Vue specs
│     ├─ Figma prototypes
│     └─ Webflow/no-code
│
├─ 5.5 3D Visualization Questions (If Selected)
│  ├─ "What should be 3D modeled?"
│  │  ├─ Product visualization
│  │  ├─ Space/environment design
│  │  ├─ Data visualization
│  │  ├─ Architectural rendering
│  │  └─ Process flow 3D diagram
│  │
│  ├─ "3D specifications:"
│  │  ├─ Rendering style? (photorealistic, stylized, wireframe)
│  │  ├─ Animation? (static, rotating, interactive)
│  │  ├─ Resolution/quality requirements?
│  │  └─ Software? (Blender specs, 3DS Max, etc.)
│  │
│  └─ "Deliverables?"
│     ├─ Rendered images
│     ├─ Animated video
│     ├─ Interactive 3D model
│     └─ Design file (for further editing)
│
└─ 5.6 Audio & Podcast Questions
   ├─ "Do you need audio content?"
   │  ├─ Podcast outline/script
   │  ├─ Background music/sound design specs
   │  ├─ Voiceover script
   │  └─ Audio branding elements
   │
   └─ "Specifications?"
      ├─ Tone & style?
      ├─ Duration?
      ├─ Format requirements?
      └─ Platform targets?