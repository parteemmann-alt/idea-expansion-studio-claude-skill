# 🧠 Idea Expansion Studio (Claude Skill)

A modular, question-driven Claude Skill that turns raw business, product, or marketing ideas into highly structured deliverables. 

Instead of dumping useless fluff when you ask for "a 100-page document," this skill forces Claude to clarify, research, outline, and get your approval via a **Control Panel** before generating deep-dive documents, pitch decks, 3D/animation concepts, and visual assets in controlled batches.

## ✨ Features

- **The Control Panel:** Claude asks you editable questions (Deliverables, Length, Audience, Voice) before doing the heavy lifting.
- **Modular Deliverables:** Request just a document, just a deck, just an animation storyboard, or any combination.
- **Infinite Scaling (Batched):** Capable of architecting 10, 50, 200, or 1000-page documents by building a blueprint first and generating chapter-by-chapter.
- **Claude-Native Artifacts:** Generates HTML/CSS slide decks, Markdown bibles, SVG diagrams, and interactive code snippets instead of faking `.pptx` or `.docx` files.
- **No Hallucinations:** Strictly separates your verified sources from hypotheses and refuses to invent fake statistics.

## 📂 File Structure

```text
idea-expansion-studio/
├── README.md              # Documentation
├── SKILL.md               # The core system prompt / skill instructions
├── question-panel.md      # (Optional) Shorthand editable control panel
└── length-map.md          # (Optional) Architecture guide for extreme lengths